package exceptions;

public class LookupTableNotLoadedException extends Exception{
  public LookupTableNotLoadedException(String s){
    super(s);
  }
}
