package exceptions;

public class PostingsListNotLoadedException extends Exception{
  public PostingsListNotLoadedException(String s){
    super(s);
  }
}
