package index;

public class TermStatistics{
  private int term_frequency;
  private int document_count;

  public TermStatistics(int term_frequency, int document_count){
    this.term_frequency = term_frequency;
    this.document_count = document_count;
  }
}
