package index;

public class Tokenizer{
  public static String[] splitOnSpaces(String input){
    return input.split(" ");
  }
}
